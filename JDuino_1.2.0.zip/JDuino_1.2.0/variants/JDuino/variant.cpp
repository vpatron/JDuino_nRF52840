#include "variant.h"
#include "wiring_constants.h"
#include "wiring_digital.h"
#include "nrf.h"

static uint32_t g_ADigitalPinMapJDuino[] =
{
  // D0 .. D13
   2,  // D0  is P0.02 (A0)
   3,  // D1  is P0.03 (A1)
  28,  // D2  is P0.28 (A2)
  29,  // D3  is P0.29 (A3)
   4,  // D4  is P0.04 (A4,SDA)
   5,  // D5  is P0.05 (A5,SCL)
  43,  // D6  is P1.11 (TX)
  44,  // D7  is P1.12 (RX)
  45,  // D8  is P1.13 (SCK)
  46,  // D9  is P1.14 (MISO)
  47,  // D10 is P1.15 (MOSI)

  // LEDs
  26,  // D11 is P0.26 (LED RED)
   6,  // D12 is P0.06 (LED BLUE)
  30,  // D13 is P0.30 (LED GREEN)
  14,  // D14 is P0.14 (READ_BAT)

  // LSM6DS3TR
  40,  // D15 is P1.08 (6D_PWR)
  27,  // D16 is P0.27 (6D_I2C_SCL)
   7,  // D17 is P0.07 (6D_I2C_SDA)
  11,  // D18 is P0.11 (6D_INT1)

  // MIC
  42,//17,//42,  // D19 is P1.10 (MIC_PWR)
  32,//26,//32,  // D20 is P1.00 (PDM_CLK)
  16,//25,//16,  // D21 is P0.16 (PDM_DATA)

  // BQ25100
  13,  // D22 is P0.13 (HICHG)
  17,  // D23 is P0.17 (~CHG)

  //
  21,  // D24 is P0.21 (QSPI_SCK)
  25,  // D25 is P0.25 (QSPI_CSN)
  20,  // D26 is P0.20 (QSPI_SIO_0 DI)
  24,  // D27 is P0.24 (QSPI_SIO_1 DO)
  22,  // D28 is P0.22 (QSPI_SIO_2 WP)
  23,  // D29 is P0.23 (QSPI_SIO_3 HOLD)

  // NFC
   9,  // D30 is P0.09 (NFC1)
  10,  // D31 is P0.10 (NFC2)

  // VBAT
  31,  // D32 is P0.10 (VBAT)

  // JDuino Extra Pins
   8,   // D33 = N1 is P0.08, GPIO
  41,   // D34 = R1 is P1.09, GPIO
  12,   // D35 = U1 is P0.12, GPIO
  15,   // D36 = AD10 is P0.15, GPIO
  34,   // D37 = W24 is P1.02, GPIO
  35,   // D38 = V23 is P1.03, GPIO
  33,   // D39 = Y23 is P1.01, GPIO
};

static uint32_t g_ADigitalPinMapNinaB301[] =
{
  0xFF,                       /* 0 */
  NRF_GPIO_PIN_MAP(0, 13),    /* 1 */
  NRF_GPIO_PIN_MAP(0, 14),    /* 2 */
  NRF_GPIO_PIN_MAP(0, 15),    /* 3 */
  NRF_GPIO_PIN_MAP(0, 16),    /* 4 */
  NRF_GPIO_PIN_MAP(0, 24),    /* 5 */
  0xFF,                       /* 6 */
  NRF_GPIO_PIN_MAP(0, 25),    /* 7 */
  NRF_GPIO_PIN_MAP(1, 00),    /* 8 */
  0xFF,                       /* 9 */
  0xFF,                       /* 10 */
  0xFF,                       /* 11 */
  0xFF,                       /* 12 */
  0xFF,                       /* 13 */
  0xFF,                       /* 14 */
  0xFF,                       /* 15 */
  NRF_GPIO_PIN_MAP(0, 3),     /* 16 */
  NRF_GPIO_PIN_MAP(0, 28),    /* 17 */
  NRF_GPIO_PIN_MAP(0, 2),     /* 18 */
  0xFF,                       /* 19 */
  NRF_GPIO_PIN_MAP(0, 31),    /* 20 */
  NRF_GPIO_PIN_MAP(1, 12),    /* 21 */
  NRF_GPIO_PIN_MAP(1, 13),    /* 22 */
  NRF_GPIO_PIN_MAP(0, 29),    /* 23 */
  NRF_GPIO_PIN_MAP(0, 30),    /* 24 */
  NRF_GPIO_PIN_MAP(0, 4),     /* 25 */
  0xFF,                       /* 26 */
  NRF_GPIO_PIN_MAP(0, 5),     /* 27 */
  NRF_GPIO_PIN_MAP(0, 9),     /* 28 */
  NRF_GPIO_PIN_MAP(0, 10),    /* 29 */
  0xFF,                       /* 30 */
  0xFF,                       /* 31 */
  NRF_GPIO_PIN_MAP(0, 11),    /* 32 */
  NRF_GPIO_PIN_MAP(1, 9),     /* 33 */
  NRF_GPIO_PIN_MAP(1, 8),     /* 34 */
  NRF_GPIO_PIN_MAP(1, 1),     /* 35 */
  NRF_GPIO_PIN_MAP(1, 2),     /* 36 */
  NRF_GPIO_PIN_MAP(1, 3),     /* 37 */
  NRF_GPIO_PIN_MAP(1, 10),    /* 38 */
  NRF_GPIO_PIN_MAP(1, 11),    /* 39 */
  NRF_GPIO_PIN_MAP(1, 15),    /* 40 */
  NRF_GPIO_PIN_MAP(1, 14),    /* 41 */
  NRF_GPIO_PIN_MAP(0, 26),    /* 42 */
  NRF_GPIO_PIN_MAP(0, 6),     /* 43 */
  NRF_GPIO_PIN_MAP(0, 27),    /* 44 */
  NRF_GPIO_PIN_MAP(0, 7),     /* 45 */
  NRF_GPIO_PIN_MAP(0, 12),    /* 46 */
  NRF_GPIO_PIN_MAP(0, 23),    /* 47 */
  NRF_GPIO_PIN_MAP(0, 21),    /* 48 */
  NRF_GPIO_PIN_MAP(0, 22),    /* 49 */
  NRF_GPIO_PIN_MAP(0, 20),    /* 50 */
  NRF_GPIO_PIN_MAP(0, 17),    /* 51 */
  NRF_GPIO_PIN_MAP(0, 19),    /* 52 */
};

uint32_t *g_ADigitalPinMap = g_ADigitalPinMapJDuino;

void selectVariant(variant_t board)
{
  if (board == BOARD_NINAB301) {
    g_ADigitalPinMap = g_ADigitalPinMapNinaB301;
  } else {
    g_ADigitalPinMap = g_ADigitalPinMapJDuino;
  }

  pinMode(PIN_QSPI_CS, OUTPUT);
	digitalWrite(PIN_QSPI_CS, HIGH);
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, HIGH);
  pinMode(LED_GREEN, OUTPUT);
  digitalWrite(LED_GREEN, HIGH);
  pinMode(LED_BLUE, OUTPUT);
  digitalWrite(LED_BLUE, HIGH);
}

void initVariant()
{
	
}

